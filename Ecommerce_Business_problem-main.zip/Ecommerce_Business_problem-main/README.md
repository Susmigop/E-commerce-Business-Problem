# Return_Cloth_Classification
Return shipping is expensive for online platforms  to bear the amount for the platforms. To Eradicate or reduce the problem, I prepared classification Problem 
